/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mysqlproject.demo;

/**
 *
 * @author ASUS
 */
public class Session {
   public static String NAME; 
   public static String EMAIL;
}
